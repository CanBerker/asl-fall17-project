The file "build.xml" is the ANT build file. Use this file to build the project
and this way we can automate the process of testing your middleware. The 'jar'
target will produce a jar file that has your ETH short id in it. 

IMPORTANT: modify the xml file so that the .jar is built with your name (look
for the definition at the beginning of the file)

